<?php
// Minimal ThinkPHP8 bootstrap placeholder (for local testing)
// In real use, replace with the ThinkPHP core framework start.php
echo "ThinkPHP8 mock bootstrap - please replace with official framework core.";
