<?php
use think\facade\Route;

Route::get('article', 'ArticleController@index');
