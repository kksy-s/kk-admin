<?php
return [
    'app_name' => env('APP_NAME', 'tp8-multiapp'),
    'debug' => env('APP_DEBUG', true),
];
