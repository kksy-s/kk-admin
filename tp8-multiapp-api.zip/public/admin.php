<?php
// Admin app entry (example)
// In real deployment replace with ThinkPHP start bootstrap
echo "Admin entry placeholder - mount your ThinkPHP bootstrap here (set app name 'admin').\n";
