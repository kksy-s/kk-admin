<?php
// generic index: route to default app or show message
echo "ThinkPHP8 Multi-App Template. Configure public/admin.php and public/cms.php as entry scripts.";
