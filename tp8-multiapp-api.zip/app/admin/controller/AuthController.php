<?php
namespace app\admin\controller;

use app\common\traits\ApiResponse;
use app\common\utils\JwtHelper;

class AuthController
{
    use ApiResponse;

    public function login()
    {
        // In ThinkPHP you can use input() helpers. This is a simplified placeholder.
        $username = $_POST['username'] ?? null;
        $password = $_POST['password'] ?? null;

        if ($username === 'admin' && $password === '123456') {
            $token = JwtHelper::createToken(['uid' => 1, 'username' => 'admin']);
            return $this->success(['token' => $token], 'login success');
        }

        return $this->error('invalid credentials', 401);
    }

    public function profile()
    {
        // request()->user in a real ThinkPHP app; placeholder:
        $user = $_SERVER['USER'] ?? ['uid' => 1, 'username' => 'admin'];
        return $this->success(['user' => $user]);
    }
}
