<?php
// Admin application entry
require __DIR__ . '/../thinkphp/start.php';
echo "\nAdmin app started (mock ThinkPHP8 bootstrap).";
