<?php
namespace app\admin\middleware;

use app\common\utils\JwtHelper;

class AuthMiddleware
{
    public function handle($request, \Closure $next)
    {
        $header = $request->header('Authorization') ?? '';
        if (!$header) {
            return json(['code' => 401, 'message' => 'Token missing']);
        }
        $token = trim(str_replace('Bearer', '', $header));
        $user = JwtHelper::verifyToken($token);
        if (!$user) {
            return json(['code' => 401, 'message' => 'Invalid token']);
        }
        // attach user to request (framework-specific; placeholder)
        $request->user = $user;
        return $next($request);
    }
}
