<?php
namespace app\middleware;

class ResponseMiddleware
{
    public function handle($request, \Closure $next)
    {
        $response = $next($request);
        // If already a JSON response (array), wrap accordingly - example placeholder.
        return $response;
    }
}
