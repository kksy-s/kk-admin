<?php
// CMS app entry (example)
echo "CMS entry placeholder - mount your ThinkPHP bootstrap here (set app name 'cms').\n";
