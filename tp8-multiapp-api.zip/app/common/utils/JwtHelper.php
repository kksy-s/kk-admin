<?php
namespace app\common\utils;

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class JwtHelper
{
    public static function key()
    {
        $cfg = include __DIR__ . '/../../../../config/jwt.php';
        return $cfg['key'] ?? 'tp8_secret_key';
    }

    public static function expire()
    {
        $cfg = include __DIR__ . '/../../../../config/jwt.php';
        return $cfg['expire'] ?? 7200;
    }

    public static function createToken($payload)
    {
        $now = time();
        $payload['iat'] = $now;
        $payload['exp'] = $now + self::expire();
        return JWT::encode($payload, self::key(), 'HS256');
    }

    public static function verifyToken($token)
    {
        try {
            return JWT::decode($token, new Key(self::key(), 'HS256'));
        } catch (\Exception $e) {
            return false;
        }
    }
}
