<?php
return [
    'key' => env('JWT_KEY', 'tp8_secret_key'),
    'expire' => 7200,
];
