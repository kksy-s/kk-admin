<?php
// Example route definitions for admin app (ThinkPHP route file)
use think\facade\Route;

Route::post('login', 'AuthController@login');
Route::group(function() {
    Route::get('profile', 'AuthController@profile');
})->middleware(\app\admin\middleware\AuthMiddleware::class);
