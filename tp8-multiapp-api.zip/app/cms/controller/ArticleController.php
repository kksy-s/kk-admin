<?php
namespace app\cms\controller;

use app\common\traits\ApiResponse;

class ArticleController
{
    use ApiResponse;

    public function index()
    {
        $articles = [
            ['id' => 1, 'title' => 'Hello World', 'content' => 'Welcome to CMS.'],
        ];
        return $this->success($articles);
    }
}
