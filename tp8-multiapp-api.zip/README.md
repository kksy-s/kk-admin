# ThinkPHP8 Multi-App RESTful API Template

Minimal template with:
- admin + cms + common apps
- JWT auth (firebase/php-jwt)
- unified API response trait
- example routes and controllers

Notes:
- This is a skeleton template to speed up development. It does NOT include the ThinkPHP core.
- After unzipping, install dependencies with Composer and place ThinkPHP 8 skeleton or framework files per your setup.

Quick start (Mac local PHP 8.2):
1. Unzip the archive:
   unzip tp8-multiapp-api.zip -d tp8-multiapp-api
2. Enter project and install deps:
   cd tp8-multiapp-api
   composer install
3. Add ThinkPHP 8 framework files (or composer require your thinkphp package).
4. Start dev server (if using built-in):
   php -S 127.0.0.1:8000 -t public
5. Access samples:
   http://127.0.0.1:8000/admin/login
   http://127.0.0.1:8000/cms/article

