<?php
// CMS application entry
require __DIR__ . '/../thinkphp/start.php';
echo "\nCMS app started (mock ThinkPHP8 bootstrap).";
